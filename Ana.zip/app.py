import pandas as pd 
import sqlite3
import joblib
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt 
from car_price_predictor import CarPricePredictor
from database import create_table, insert_user_input, fetch_all_data
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split

# Modelio ir skalės įkėlimas
model = joblib.load('best_model.pkl')
scaler = joblib.load('scaler.pkl')

# Duomenų bazės lentelės kūrimas
create_table()

# Automobilių su panašiomis kainomis paieškos funkcija
def find_matching_cars(predicted_price, df):
# Filtruoti automobilius, kurių kainos yra ±500 EUR nuo prognozuojamos kainos
        matching_cars = df[df['kaina'].between(predicted_price - 500, predicted_price + 500)]
        return matching_cars[['gamintojas', 'kaina']]

# Pagrindinio meniu funkcija
def main_menu():
    print('--------------------')
    print("Pasirinkite veiksmą:")
    print('--------------------')
    print("1. Įvesti automobilio duomenis ir prognozuoti kainą")
    print('--------------------')
    print("2. Peržiūrėti visus įrašus duomenų bazėje")
    print('--------------------')
    print("3. Išeiti iš programos")

# Vartotojo duomenų įvedimo funkcija
def input_data():
    while True:
        try:
            print("\nĮveskite automobilio duomenis:")
            print('--------------------')
            print('Marke: ')
            print('           ')
            gamintojai = {0:'BMW', 1:'Skoda', 2:'Audi', 3:'Volkswagen', 4:'Peugeot', 5:'Volvo', 6:'Mercedes-Benz', 7:'Subaru', 8:'Toyota', 9:'LandRover', 10:'Jaguar', 11:'Alfa', 12:'Opel', 13:'Honda', 14:'Nissan', 15:'Suzuki', 16:'Kia', 17:'Chevrolet', 18:'Hyundai', 19:'Infiniti', 20:'Renault', 21:'Citroen', 22:'Chrysler', 23:'Mitsubishi', 24:'Maserati', 25:'Porsche', 26:'Ford', 27:'Mazda', 28:'Lexus', 29:'Seat', 30:'Tesla', 31:'Jeep', 32:'Lancia', 33:'Moskvich', 34:'Fiat', 35:'Smart', 36:'Mini', 37:'Daihatsu', 38:'Pontiac', 39:'Dacia', 40:'Saab', 41:'Dodge', 42:'SsangYong', 43:'DR', 44:'Iveco', 45:'Cadillac', 46:'Aixam', 47:'Microcar', 48:'DS', 49:'Ligier'}
            for key, value in gamintojai.items():
                print(key, value)
            gamintojas = int(input('Pasirinkite marke (numeris): '))
            print('--------------------')
            metai = int(input('Metai: '))
            print('--------------------')
            rida = float(input('Rida (km): '))
            print('--------------------')
            kW = float(input('Variklio galia (kW): '))
            print('--------------------')
            print('Kuras: ')
            print('         ')
            print("0: Benzinas, 1: Dyzelinas, 2: Elektra, 3: Benzinas / elektra, 4: Dyzelinas / elektra, 5: Benzinas / dujos")
            print('       ')
            kuras = int(input('Pasirinkite kura (numeris): '))
            print('--------------------')
            print('Pavarų dėžė: ')
            print('                 ')
            print("0: Mechaninė, 1: Automatinė")
            print('         ')
            pavaros = int(input('Pasirinkite pavaru deze (numeris): '))
            print('--------------------')
            return gamintojas, metai, rida, kW, kuras, pavaros
        except ValueError:
            print('Įvedėte neteisingą reikšmę. Bandykite dar kartą.')

# Funkcija grafiko sudarymui
def plot_matching_cars(matching_cars, predicted_price):
    gamintojai = {0: 'BMW', 1: 'Skoda', 2: 'Audi', 3: 'Volkswagen', 4: 'Peugeot', 5: 'Volvo', 6: 'Mercedes-Benz', 7: 'Subaru', 8: 'Toyota', 9: 'LandRover', 10: 'Jaguar', 11: 'Alfa', 12: 'Opel', 13: 'Honda', 14: 'Nissan', 15: 'Suzuki', 16: 'Kia', 17: 'Chevrolet', 18: 'Hyundai', 19: 'Infiniti', 20: 'Renault', 21: 'Citroen', 22: 'Chrysler', 23: 'Mitsubishi', 24: 'Maserati', 25: 'Porsche', 26: 'Ford', 27: 'Mazda', 28: 'Lexus', 29: 'Seat', 30: 'Tesla', 31: 'Jeep', 32: 'Lancia', 33: 'Moskvich', 34: 'Fiat', 35: 'Smart', 36: 'Mini', 37: 'Daihatsu', 38: 'Pontiac', 39: 'Dacia', 40: 'Saab', 41: 'Dodge', 42: 'SsangYong', 43: 'DR', 44: 'Iveco', 45: 'Cadillac', 46: 'Aixam', 47: 'Microcar', 48: 'DS', 49: 'Ligier'}

    # Pakeisti gamintojo indeksus į vardus
    matching_cars['gamintojas'] = matching_cars['gamintojas'].map(gamintojai)
    
    plt.figure(figsize=(10, 6))
    plt.bar(matching_cars['gamintojas'], matching_cars['kaina'])
    plt.axhline(y=predicted_price, color='r', linestyle='--', label=f'Prognozuojama kaina: {predicted_price:.2f} EUR')
    plt.xlabel('Gamintojas')
    plt.ylabel('Kaina (EUR)')
    plt.title('Automobiliai su panašiomis kainomis')
    plt.xticks(rotation=45, ha='right')
    plt.legend()
    plt.tight_layout()
    plt.show()

# Automobilio kainos prognozavimo funkcija
def predict_price():
    gamintojas, metai, rida, pavaros, kuras, kW = input_data()
    df = pd.read_csv('cleaned_mobile_autoplius.csv', sep=';')
    user_data = pd.DataFrame([[gamintojas, metai, rida, pavaros, kuras, kW]],
                             columns=['gamintojas', 'metai', 'rida', 'pavaros', 'kuras', 'kW'])
    user_data_scaled = scaler.transform(user_data)

# Prognozuoti automobilio kainą
    predicted_price = model.predict(user_data_scaled)[0]
    print(f"Prognozuojama automobilio kaina: {predicted_price:.2f} EUR")

    # Ieškoti markių pagal prognozuotą kainą
    gamintojai = {0:'BMW', 1:'Skoda', 2:'Audi', 3:'Volkswagen', 4:'Peugeot', 5:'Volvo', 6:'Mercedes-Benz', 7:'Subaru', 8:'Toyota', 9:'LandRover', 10:'Jaguar', 11:'Alfa', 12:'Opel', 13:'Honda', 14:'Nissan', 15:'Suzuki', 16:'Kia', 17:'Chevrolet', 18:'Hyundai', 19:'Infiniti', 20:'Renault', 21:'Citroen', 22:'Chrysler', 23:'Mitsubishi', 24:'Maserati', 25:'Porsche', 26:'Ford', 27:'Mazda', 28:'Lexus', 29:'Seat', 30:'Tesla', 31:'Jeep', 32:'Lancia', 33:'Moskvich', 34:'Fiat', 35:'Smart', 36:'Mini', 37:'Daihatsu', 38:'Pontiac', 39:'Dacia', 40:'Saab', 41:'Dodge', 42:'SsangYong', 43:'DR', 44:'Iveco', 45:'Cadillac', 46:'Aixam', 47:'Microcar', 48:'DS', 49:'Ligier'}
    matching_cars = find_matching_cars(predicted_price, df)
    print("Automobiliai, kurių kainos yra artimos prognozuotoms:")
    for _, row in matching_cars.iterrows():
        print(f"{gamintojai[int(row['gamintojas'])]}: {row['kaina']} EUR")

    matching_prices = matching_cars['kaina']

    if len(matching_prices) > 0:
        prediction_accuracy = 1.0 - (abs(predicted_price - matching_prices.mean()) / matching_prices.mean())
        print(f'Prognozes tikslumas: {prediction_accuracy:.2%}')
    else:
        prediction_accuracy = 0.0
        print('Nerasta atitikmenų automobilių pagal kainą ±500 EUR intervale.')

# Įrašyti vartotojo duomenis į duomenų bazę
    insert_user_input(gamintojas, metai, rida, pavaros, kuras, kW, predicted_price, prediction_accuracy)

 # Sukurti ir parodyti grafiką
    plot_matching_cars(matching_cars, predicted_price)

# Duomenų bazės įrašų peržiūros funkcija
def view_database():
    data = fetch_all_data()
    print("\nVisi įrašai duomenų bazėje:")
    for row in data:
        print(row)

# Pagrindinė programa
def main():
    while True:
        main_menu()
        print('--------------------')
        choice = input("Pasirinkite veiksmą (1/2/3): ")
        if choice == '1':
            predict_price()
        elif choice == '2':
            view_database()
        elif choice == '3':
            print('--------------------')
            print("Programa baigė darbą.")
            break
        else:
            print('--------------------')
            print("Neteisingas pasirinkimas. Bandykite dar kartą.")

if __name__ == "__main__":
    main()           






